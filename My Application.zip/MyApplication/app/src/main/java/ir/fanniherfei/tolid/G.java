package ir.fanniherfei.tolid;

import android.app.Application;
import android.content.SharedPreferences;
import android.graphics.Bitmap;

public class G extends Application {
    public static String url="";
    public static int last=0;
    public static boolean connect=false;
    public static String result="";
    public static String resultText="";
    public static int importProjectNumber=1;
    public static int importPeopleNumber=1;
    public static boolean send=false;
    public static boolean recieve=false;
    public static String change="";
    public static int changenum=0;
    public static boolean changebill=false;
    public static String[] changebilltext=new String[3];
    public static int positionpeople=0;
    public static int choose=0;
    public static String password="";
    public static String billtext="";
    public static boolean progress=false;
    public static boolean team=false;
    public static String url2="";
    public static int position=0;
    public static String name="";
    public static String projects="";
    public static String impr="";
    public static boolean importin=false;
    public static boolean incom=false;
    public static String news="";
    public static boolean inincome=false;
    public static boolean conn=true;
    public static int billchangenum=0;
    public static int billpos=0;
    public static int importbill=0;
    public static String[][] newnew=new String[100][14];
    public static boolean newnews=false;
    public static int newnewsnum=0;
    public static Bitmap project[]=new Bitmap[10000];
}
